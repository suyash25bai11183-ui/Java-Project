# ClubGear Screenshot Evidence

These images correspond to the console outputs documented in `docs/SCREENSHOTS.md`.

Files:
- startup.png
- main-menu.png
- equipment-list.png
- booking-confirmation.png
- booking-conflict.png
- damaged-equipment.png
- approval-return.png
- maintenance.png
- reports.png
- invalid-input.png
- save-load.png
- testing.png
